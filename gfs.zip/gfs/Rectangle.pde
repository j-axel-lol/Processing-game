class Rectangle {

    String tag;
    Rectangle rect;
    int angle;
    int hp = 25;

    boolean hidden;
    float timer;
    float modifier;
    int type;

    PVector pos;
    PVector flyingDir;
    PVector screenDir;

    float x;
    float y;
    int w;
    int ht;

    color rClr;
    color clr;
    float internalTime;

    Rectangle(float X, float Y, int W, int Ht, String Tag, color Clr) {
        tag = Tag;
        clr = Clr;
        hidden = false;

        x = X;
        y = Y;
        w = W;
        ht = Ht;
        pos = new PVector(x, y);

        modifier = random(0.8f, 1.6f);

    }
    void Move(float xchange, float ychange) {
        if (hidden) return;
        noStroke();

        if (tag == "Enemy") {
            xchange *= modifier;
            ychange *= modifier;
        }

        x += xchange;
        y += ychange;

        pos = new PVector(x, y);

        fill(clr);
        rect(x + xchange, y + ychange, w, ht);

        if (tag == "Player") {
            textSize(10);
            fill(0, 0, 0);
        }
    }
    void Render() {
        if (hidden) return;
        internalTime += 1 / frameRate;

        if (tag == "Boss") {

            if (internalTime > 1) {
                internalTime = 0;
                rClr = color(random(30, 255), random(30, 255), random(30, 255));
            }
            clr = lerpColor(clr, rClr, internalTime / 100);
        }

        fill(clr);
        rect(x, y, w, ht);
    }
    void RespawnEnemy() {
        type = int(random(0, 2));

        int num = int(random(5));
        if (num == 0) {
            y = -ht;
            x = int(random(0, 1280));
            screenDir = new PVector(0, 1);
        }
        else if (num == 1) {
            y = 720 + ht;
            x = int(random(0, 1280));
            screenDir = new PVector(0, -1);
        }
        else if (num == 2) {
            x = -w;
            y = int(random(50, 720));

            screenDir = new PVector(1, 0);
        }
        else {
            x = 1280 + w;
            y = int(random(50, 720));
            screenDir = new PVector(-1, 0);
        }
        pos = new PVector(x, y);
    }
    void RespawnFood() {
        Move(-x, -y);
        Move(int(random(0, 1280 - w)), int(random(50, 720 - ht)));
    }
    void MoveToPlayer(PVector Dir) {
        if (hidden) return;

        flyingDir = Dir;
        Move(flyingDir.x, flyingDir.y);
    }
}