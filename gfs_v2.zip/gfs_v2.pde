Rectangle player;
Rectangle boss;
Rectangle food;
Rectangle heal;

ArrayList<Rectangle> rects = new ArrayList<Rectangle>();
ArrayList<String> keys = new ArrayList<String>();

int yPos = 0;
int xPos = 0;
int multiplier = 2;
int score = 0;

float totalTime = 0;
float waveTime;
float waveLimit = 10;

boolean bossSpawned;
int hp = 3;
int waves = 0;
float cooldown = 0;
int cap = 3;

JSONObject jsonSave;
JSONObject jsonLoad;

PFont decrypted;
color bg;

boolean paused = false;
boolean fullscreen = false;

void setup() {
    frameRate(200);
    player = new Rectangle(0, 50, 75, 75, "Player", color(255, 200, 255));
    food = new Rectangle(800, 200, 25, 25, "Food", color(255, 255, 0));
    heal = new Rectangle(800, 200, 25, 25, "Heal", color(49, 182, 117));

    rects.add(food);
    rects.add(heal);
    heal.hidden = true;

    food.RespawnFood();

    jsonSave = new JSONObject();
    jsonLoad = loadJSONObject("saveFile.json");
    decrypted = createFont("Decrypted.ttf", 128);

    bg = color(14, 28, 54);
}
void settings() {
    if (!fullscreen) size(1280, 770);
    else fullScreen();
}
void draw() {
    if (paused || !focused) return;

    background(bg);
    totalTime += 1 / frameRate;
    if (!bossSpawned) waveTime += 1 / frameRate;
    cooldown -= 1 / frameRate;
    cooldown = constrain(cooldown, 0, 0.5f);

    xPos = 0;
    yPos = 0;

    for (int i = 0; i < rects.size(); i++) {
        Rectangle rect = rects.get(i);

        rects.get(i).Render();

        if (rect.tag == "Enemy" && !rect.hidden) {

            PVector dir = new PVector((player.x + player.w / 2) - rect.x, (player.y + player.ht / 2) - rect.y);
            dir.normalize();

            if (rect.type == 0) {
                if (rect.screenDir.x == -1 && rect.pos.x > width - 150 || rect.screenDir.x == 1 && rect.pos.x < 150
                    || rect.screenDir.y == -1 && rect.pos.y > height - 100 || rect.screenDir.y == 1 && rect.pos.y < 100) {
                    rect.Move(rect.screenDir.x, rect.screenDir.y);
                }
                else {
                    rect.timer += 0.005f;
                    if (rect.timer > 2.5f) {
                        rects.add(new Rectangle(rect.x, rect.y, 10, 10, "Bullet", color(255, 165, 0)));
                        rects.get(rects.size() - 1).flyingDir = dir.mult(2f);
                        rect.timer = 0;
                    }
                }
            }
            else rect.MoveToPlayer(dir);

            for (int j = 0; j < rects.size(); j++) {
                if (CheckCollision(rect, rects.get(j))) {
                    if (rects.get(j).tag == "PlayerBullet") {
                        rects.remove(rects.get(j));
                        rects.remove(rect);
                    }
                }
            }
        }
        if (rect.tag == "Boss" && !rect.hidden) {
            if (rect.screenDir.x == -1 && rect.pos.x > width - 200 || rect.screenDir.x == 1 && rect.pos.x < 200
                || rect.screenDir.y == -1 && rect.pos.y > height - 150 || rect.screenDir.y == 1 && rect.pos.y < 150) {
                rect.Move(rect.screenDir.x, rect.screenDir.y);
            }
            else {
                rect.timer += 0.005f;
                if (rect.timer >= 0.2f / (waves / 5)) {
                    rects.add(new Rectangle(rect.x + rect.w / 2, rect.y + rect.ht / 2, 10, 10, "Bullet", color(255, 165, 0)));
                    PVector dir = new PVector(cos(rect.angle), sin(rect.angle)).normalize();
                    rects.get(rects.size() - 1).flyingDir = dir.mult(2f);

                    rect.angle = (rect.angle + 3) % 360;
                    rect.timer = 0;
                }
            }
        }
        if (rect.tag == "Bullet" || rect.tag == "PlayerBullet") {
            if (rect.internalTime > 10) rects.remove(rect);
            rect.MoveToPlayer(rect.flyingDir);
        }
        if (bossSpawned) {
            if (CheckCollision(boss, rect)) {
                if (rect.tag == "PlayerBullet") {
                    rects.remove(rect);
                    boss.hp--;
                    if (boss.hp <= 0) {
                        boss.angle = 0;
                        boss.hidden = true;
                        food.hidden = false;
                        heal.hidden = false;
                        bossSpawned = false;
                        bg = color(random(0, 61), random(0, 61), random(0, 61));
                        food.RespawnFood();
                        heal.RespawnFood();
                    }
                }
            }
        }
        if (CheckCollision(player, rect)) {
            
            if (rect.tag == "Food") {
                score++;
                if (!bossSpawned) food.RespawnFood();
                else food.hidden = true;
            }
            else if (rect.tag == "Heal") {
                hp += 2;
                heal.hidden = true;
            }
            else if (rect.tag == "Enemy" || rect.tag == "Boss") {
                DecreaseHealth();
                if (rect.tag == "Enemy") rect.RespawnEnemy();
            }
            else if (rect.tag == "Bullet") {
                DecreaseHealth();
                rects.remove(rect);
            }
        }
    }

    if (keyPressed) {

        if (Contains(keys, 'a') || Contains(keys, 'A')) if (player.x > 0) xPos--;
        if (Contains(keys, 'd') || Contains(keys, 'D')) if (player.x + player.w < width) xPos++;
        if (Contains(keys, 'w') || Contains(keys, 'W')) if (player.y > 50) yPos--;
        if (Contains(keys, 's') || Contains(keys, 'S')) if (player.y + player.ht < height) yPos++;
    }
    player.Move(xPos * multiplier, yPos * multiplier);

    if (waveTime > waveLimit) {
        if (waves % 10 == 0 && waves > 0) waveLimit += 2.5f;
        waveTime = 0;
        NewWave();
    }

    fill(50);
    rect(0, 0, width, 50);

    textAlign(CENTER);
    textFont(decrypted);
    textSize(45);
    fill(160);

    if (totalTime < 5f) text("wasd - movement, click - shoot", width / 2, 100);

    text("hp: " + hp, width / 6, 30);
    text("score: " + score, 2 * (width / 6), 30);
    text("time: " + nf(totalTime, 0, 2), 4 * (width / 6), 30);
    text("wave: " + waves, 5 * (width / 6), 30);
}
void mousePressed() {
    if (cooldown > 0) return;
    Rectangle rect = new Rectangle(player.x + player.w / 2, player.y + player.ht / 2, 10, 10, "PlayerBullet", color(124, 22, 193));
    rects.add(rect);
    PVector dir = new PVector(rect.pos.x - mouseX, rect.pos.y - mouseY).normalize();
    rect.flyingDir = dir.mult(-3f);
    cooldown = 0.25f;
}
void keyPressed() {
    if (!Contains(keys, key)) keys.add(str(key));
    if (keyCode == ESC) {
        paused = !paused;
        if (paused) text("paused", width / 2, 200);
        key = 0;
    }
}
void keyReleased() {
    if (Contains(keys, key)) keys.remove(str(key));
}
boolean Contains(ArrayList<String> lst, char key) {
    boolean contains = false;
    for (int i = 0; i < lst.size(); i++) {
        if (lst.get(i).equals(str(key))) contains = true;
    }
    return contains;
}
boolean CheckCollision(Rectangle r1, Rectangle r2) {
    if (r1.hidden || r2.hidden) return false;

    else if (r1.x + r1.w < r2.x) return false;
    else if (r1.x > r2.x + r2.w) return false;
    else if (r1.y + r1.ht < r2.y) return false;
    else if (r1.y > r2.y + r2.ht) return false;
    else return true;
}
void DecreaseHealth() {
    hp--;
    if (hp <= 0) {
        frameRate(0);
        exit();
    }
}
void NewWave() {
    waves++;

    if (waves % 10 == 0 && waves > 0) {
        bossSpawned = true;
        boss = new Rectangle(0, 0, 100, 100, "Boss", color(0, 191, 255));
        boss.hp = 25 * (waves / 10);
        rects.add(boss);
        boss.RespawnEnemy();
        return;
    }

    if (waves % 4 == 0 && waves > 0) cap++;

    for (int i = 0; i < cap; i++) {
        rects.add(new Rectangle(0, 0, 25, 25, "Enemy", color(255, 0, 0)));
        rects.get(rects.size() - 1).RespawnEnemy();
    }
}
void exit(){
    if (jsonLoad.getInt("hi-score") < score) jsonSave.setInt("hi-score", score);
    else jsonSave.setInt("hi-score", jsonLoad.getInt("hi-score"));

    if (jsonLoad.getInt("waves survived") < waves) jsonSave.setInt("waves survived", waves);
    else jsonSave.setInt("waves survived", jsonLoad.getInt("waves survived"));

    if (jsonLoad.getFloat("seconds survived") < totalTime) jsonSave.setFloat("seconds survived", totalTime);
    else jsonSave.setFloat("seconds survived", jsonLoad.getFloat("seconds survived"));

    saveJSONObject(jsonSave, "saveFile.json");
}
